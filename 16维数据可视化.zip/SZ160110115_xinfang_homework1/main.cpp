#include <fstream>
#include <string>
#include <iomanip>
#include <iostream>
#include <cmath>

using namespace std;



//����ṹ�� ���� 
struct Bank
{
	int age;
	string job;
	string marital;
	string education;
	string credit;
	int balance;
	string housing;
	string loan;
	string contact;
	int day;
	string month;
	int duration;
	int campaigh;
	int pdays;
	int previous;
	string poutcome;
	string y;
};

//�˵����� 
/*
void mine()
{
	cout << setw(20)<< "age" << '\t';
	cout << setw(20)<< "job" << '\t';
	cout << setw(20)<< "marital" << '\t';
	cout << setw(20)<< "education" << '\t';
	cout << setw(20)<< "default" << '\t';
	cout << setw(20)<< "balance" << '\t';
	cout << setw(20)<< "housing" << '\t';
	cout << setw(20)<< "loan" << '\t';
	cout << setw(20)<< "contact" << '\t';
	cout << setw(20)<< "day" << '\t';
	cout << setw(20)<< "month" << '\t';
	cout << setw(20)<< "duration" << '\t';
	cout << setw(20)<< "campaign" << '\t';
	cout << setw(20)<< "pdays" << '\t';
	cout << setw(20)<< "previous" << '\t';
	cout << setw(20)<< "poutcome" << '\t';
	cout << setw(20)<< "y" << '\n';
}*/

Bank bank[45213];

int main()
{
	int i = 0;
	int banknum = 0;
	fstream file("bankfull.txt");
	//��ֵ�����Ե���غ����� 
	void op_age(Bank bank[],int banknum);
	void op_balance(Bank bank[],int banknum);
	void op_day(Bank bank[],int banknum);
	void op_duration(Bank bank[],int banknum);	
	void op_campaigh(Bank bank[],int banknum);
	void op_pdays(Bank bank[],int banknum);
	void op_previous(Bank bank[],int banknum);
	
	//����ֵ�����Ե���غ����� 
	void op_job(Bank bank[],int banknum);
	void op_marital(Bank bank[],int banknum);
	void op_credit(Bank bank[],int banknum);
	void op_education(Bank bank[],int banknum);	
	void op_housing(Bank bank[],int banknum);
	void op_loan(Bank bank[],int banknum);
	void op_contact(Bank bank[],int banknum);
	void op_month(Bank bank[],int banknum);
	void op_poutcome(Bank bank[],int banknum);
	void op_y(Bank bank[],int banknum);	
	
	
	//void task(Bank bank[],int banknum);
	
	
	//��ʾ�˵� 
	//mine();
	
	//�ļ����������ļ��е����ݶ�ȡ�� 
	if(!file)
	{
		cerr<<"open error!" << endl;
		exit(1);
	}
	while(!file.eof())
	{
		file >> bank[i].age >> bank[i].job >>bank[i].marital >>bank[i].education >>bank[i].credit >>bank[i].balance >> bank[i].housing >>  bank[i].loan >> bank[i].contact >> bank[i].day >> bank[i].month >> bank[i].duration >> bank[i].campaigh >> bank[i].pdays >> bank[i].previous >> bank[i].poutcome >> bank[i].y;
		/*cout << setw(20)<< bank[i].age << '\t';
		cout << setw(20)<< bank[i].job << '\t';
		cout << setw(20)<< bank[i].marital << '\t';
		cout << setw(20)<< bank[i].education << '\t';
		cout << setw(20)<< bank[i].credit << '\t';
		cout << setw(20)<< bank[i].balance << '\t';
		cout << setw(20)<< bank[i].housing << '\t';
		cout << setw(20)<< bank[i].loan << '\t';
		cout << setw(20)<< bank[i].contact << '\t';
		cout << setw(20)<< bank[i].day << '\t';
		cout << setw(20)<< bank[i].month << '\t';
		cout << setw(20)<< bank[i].duration << '\t';
		cout << setw(20)<< bank[i].campaigh << '\t';
		cout << setw(20)<< bank[i].pdays << '\t';
		cout << setw(20)<< bank[i].previous << '\t';
		cout << setw(20)<< bank[i].poutcome << '\t';
		cout << setw(20)<< bank[i].y << '\n';*/
		i++;
		banknum++;
	}
	
	banknum;
	cout << "The total is "<< banknum <<"\n\n\n"<< endl;
	
	op_age(bank,banknum);
	op_balance(bank,banknum);
	op_day(bank,banknum);
	op_duration(bank,banknum);	
	op_campaigh(bank,banknum);
	op_pdays(bank,banknum);
	op_previous(bank,banknum);
	 
	op_job(bank,banknum);
	op_marital(bank,banknum);
	op_credit(bank,banknum);
	op_education(bank,banknum);	
	op_housing(bank,banknum);
	op_loan(bank,banknum);
	op_contact(bank,banknum);
	op_month(bank,banknum);
	op_poutcome(bank,banknum);
	op_y(bank,banknum);

	//task(bank,banknum);
	
	return 0; 
}

//��ֵ�����Ե���غ�����
 
void op_age(Bank bank[],int banknum)
{
	int i = 0;       //�ṹ�������־λ 
	int sum = 0;     //��ƽ�����ĺ� 
	int sum2 = 0;	//�󷽲�����еĺ� 
	int max = 0;		//���ֵ 
	int min = 100000;	//��Сֵ 
	float average = 0;	//ƽ���� 
	float Fchar = 0;	//���� 
	
	cout <<"**********age**********"<<'\n';		//��ӡ�Ʊ����� 
	
	for(i = 0; i < banknum ; i++)
	{
		sum += bank[i].age;		//�ۼ���� 
		max = bank[i].age > max ? bank[i].age : max;	//�����ҵ���� 
		min = bank[i].age < min ? bank[i].age : min;	//�����ҵ���С 
	}
	average = (float)sum/banknum;
	
	for(i = 0; i < banknum ; i++)
	{
		sum2 += pow(bank[i].age - average,2);	//�ۼ��󷽲�� 
	}
	
	Fchar = (float)sum2/banknum;	//�󷽲� 
	cout << "The average of age is " << (float)sum/banknum << endl;
	cout << "The max of age is " << max << endl;
	cout << "The min of age is " << min << endl;
	cout << "The Jcha of age is " <<max - min << endl;
	cout << "The Fcha of age is " << Fchar << endl;	
	cout <<"\n\n\n";
}

void op_balance(Bank bank[],int banknum)
{
	int i = 0;
	int sum = 0;
	int sum2 = 0;
	int max = 0;
	int min = 100000;
	float average = 0;
	float Fchar = 0;
	
	cout <<"**********balance**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		sum += bank[i].balance;
		max = bank[i].balance > max ? bank[i].balance : max;
		min = bank[i].balance < min ? bank[i].balance : min;
	}
	average = (float)sum/banknum;
	
	for(i = 0; i < banknum ; i++)
	{
		sum2 += pow(bank[i].balance - average,2);
	}
	
	Fchar = (float)sum2/banknum;
	cout << "The average of balance is " << (float)sum/banknum << endl;
	cout << "The max of balance is " << max << endl;
	cout << "The min of balance is " << min << endl;
	cout << "The Jcha of balance is " <<max - min << endl;
	cout << "The Fcha of balance is " << Fchar << endl;	
	cout <<"\n\n\n";
}

void op_day(Bank bank[],int banknum)
{
	int i = 0;
	int sum = 0;
	int sum2 = 0;
	int max = 0;
	int min = 100000;
	float average = 0;
	float Fchar = 0;
		
	cout <<"**********day**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		sum += bank[i].day;
		max = bank[i].day > max ? bank[i].day : max;
		min = bank[i].day < min ? bank[i].day : min;
	}
	average = (float)sum/banknum;
	
	for(i = 0; i < banknum ; i++)
	{
		sum2 += pow(bank[i].day - average,2);
	}
	
	Fchar = (float)sum2/banknum;
	cout << "The average of day is " << (float)sum/banknum << endl;
	cout << "The max of day is " << max << endl;
	cout << "The min of day is " << min << endl;
	cout << "The Jcha of day is " <<max - min << endl;
	cout << "The Fcha of day is " << Fchar << endl;
	cout <<"\n\n\n";	
}

void op_duration(Bank bank[],int banknum)
{
	int i = 0;
	int sum = 0;
	int sum2 = 0;
	int max = 0;
	int min = 100000;
	float average = 0;
	float Fchar = 0;
	
	cout <<"**********duration**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		sum += bank[i].duration;
		max = bank[i].duration > max ? bank[i].duration : max;
		min = bank[i].duration < min ? bank[i].duration : min;
	}
	average = (float)sum/banknum;
	
	for(i = 0; i < banknum ; i++)
	{
		sum2 += pow(bank[i].duration - average,2);
	}
	
	Fchar = (float)sum2/banknum;
	cout << "The average of duration is " << (float)sum/banknum << endl;
	cout << "The max of duration is " << max << endl;
	cout << "The min of duration is " << min << endl;
	cout << "The Jcha of duration is " <<max - min << endl;
	cout << "The Fcha of duration is " << Fchar << endl;
	cout <<"\n\n\n";	
}

void op_campaigh(Bank bank[],int banknum)
{
	int i = 0;
	int sum = 0;
	int sum2 = 0;
	int max = 0;
	int min = 100000;
	float average = 0;
	float Fchar = 0;
	
	cout <<"**********campaigh**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		sum += bank[i].campaigh;
		max = bank[i].campaigh > max ? bank[i].campaigh : max;
		min = bank[i].campaigh < min ? bank[i].campaigh : min;
	}
	average = (float)sum/banknum;
	
	for(i = 0; i < banknum ; i++)
	{
		sum2 += pow(bank[i].campaigh - average,2);
	}
	
	Fchar = (float)sum2/banknum;
	cout << "The average of campaigh is " << (float)sum/banknum << endl;
	cout << "The max of campaigh is " << max << endl;
	cout << "The min of campaigh is " << min << endl;
	cout << "The Jcha of campaigh is " <<max - min << endl;
	cout << "The Fcha of campaigh is " << Fchar << endl;
	cout <<"\n\n\n";	
}

void op_pdays(Bank bank[],int banknum)
{
	int i = 0;
	int sum = 0;
	int sum2 = 0;
	int max = 0;
	int min = 100000;
	float average = 0;
	float Fchar = 0;
	
	cout <<"**********pdays**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		sum += bank[i].pdays;
		max = bank[i].pdays > max ? bank[i].pdays : max;
		min = bank[i].pdays < min ? bank[i].pdays : min;
	}
	average = (float)sum/banknum;
	
	for(i = 0; i < banknum ; i++)
	{
		sum2 += pow(bank[i].pdays - average,2);
	}
	
	Fchar = (float)sum2/banknum;
	cout << "The average of pdays is " << (float)sum/banknum << endl;
	cout << "The max of pdays is " << max << endl;
	cout << "The min of pdays is " << min << endl;
	cout << "The Jcha of pdays is " <<max - min << endl;
	cout << "The Fcha of pdays is " << Fchar << endl;
	cout <<"\n\n\n";	
}

void op_previous(Bank bank[],int banknum)
{
	int i = 0;
	int sum = 0;
	int sum2 = 0;
	int max = 0;
	int min = 100000;
	float average = 0;
	float Fchar = 0;
	
	cout <<"**********previous**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		sum += bank[i].previous;
		max = bank[i].previous > max ? bank[i].previous : max;
		min = bank[i].previous < min ? bank[i].previous : min;
	}
	average = (float)sum/banknum;
	
	for(i = 0; i < banknum ; i++)
	{
		sum2 += pow(bank[i].previous - average,2);
	}
	
	Fchar = (float)sum2/banknum;
	cout << "The average of previous is " << (float)sum/banknum << endl;
	cout << "The max of previous is " << max << endl;
	cout << "The min of previous is " << min << endl;
	cout << "The Jcha of previous is " <<max - min << endl;
	cout << "The Fcha of previous is " << Fchar << endl;
	cout <<"\n\n\n";	
}
	
//����ֵ�����Ե���غ����� 
void op_job(Bank bank[],int banknum)
{
	string family[100];		//������� 
	int familynum[100] = {0};	//ÿ������Ƶ�� 
	int i = 0;		//��־λi 
	int j = 0;		//��־λj 
	int flag = 0;	//��־λflag 
	int max = 0;	//Ƶ�����ֵmax 
		
	cout <<"**********job**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		for(j = 0; j < 100; j++)
		{
			if(bank[i].job == family[j])	//������������������Ƶ�� 
			{
				familynum[j]++;
				break; 
			} 
			else if((bank[i].job != family[j])&&(j >= flag)) //�����µ���� 
			{
				family[j] = bank[i].job;
				flag++;
				familynum[j]++;
				break;
			}
			else continue;
	    }
	}
	
	for(i = 0; i < flag; i++)	//��ӡ 
	{
		cout<<family[i] << " is " << familynum[i] <<". Frequency is " << (float)familynum[i]/banknum << endl;
	}
	
	for(i = 0; i < flag; i++) //�ҵ����Ƶ�� 
	{
		max = familynum[i] > max ? familynum[i] : max;
	}
	
	for(i = 0; i <flag; i++)	//�ҵ����Ƶ����Ӧ����� 
	{
		if(max == familynum[i]) 
		{
			max = i;
			break;
		}
	}
	cout << "The most is " << family[i] << endl;
	cout <<"\n\n\n";
}

void op_marital(Bank bank[],int banknum)
{
	string family[100];
	int familynum[100] = {0};
	int i = 0;
	int j = 0;
	int flag = 0;
	int max = 0;
			
	cout <<"**********marital**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		for(j = 0; j < 100; j++)
		{
			if(bank[i].marital == family[j])
			{
				familynum[j]++;
				break; 
			} 
			else if((bank[i].marital != family[j])&&(j >= flag))
			{
				family[j] = bank[i].marital;
				flag++;
				familynum[j]++;
				break;
			}
			else continue;
	    }
	}
	
	for(i = 0; i < flag; i++)
	{
		cout<<family[i] << " is " << familynum[i] <<". Frequency is " << (float)familynum[i]/banknum << endl;
	}
	
	for(i = 0; i < flag; i++)
	{
		max = familynum[i] > max ? familynum[i] : max;
	}
	
	for(i = 0; i <flag; i++)
	{
		if(max == familynum[i]) 
		{
			max = i;
			break;
		}
	}
	cout << "The most is " << family[i] << endl;
	cout <<"\n\n\n";
}

void op_credit(Bank bank[],int banknum)
{
	string family[100];
	int familynum[100] = {0};
	int i = 0;
	int j = 0;
	int flag = 0;
	int max = 0;
			
	cout <<"**********credit**********"<<'\n';
	
	
	for(i = 0; i < banknum ; i++)
	{
		for(j = 0; j < 100; j++)
		{
			if(bank[i].credit == family[j])
			{
				familynum[j]++;
				break; 
			} 
			else if((bank[i].credit != family[j])&&(j >= flag))
			{
				family[j] = bank[i].credit;
				flag++;
				familynum[j]++;
				break;
			}
			else continue;
	    }
	}
	
	for(i = 0; i < flag; i++)
	{
		cout<<family[i] << " is " << familynum[i] <<". Frequency is " << (float)familynum[i]/banknum << endl;
	}
	for(i = 0; i < flag; i++)
	{
		max = familynum[i] > max ? familynum[i] : max;
	}
	
	for(i = 0; i <flag; i++)
	{
		if(max == familynum[i]) 
		{
			max = i;
			break;
		}
	}
	cout << "The most is " << family[i]<<endl;
	cout <<"\n\n\n";
}

void op_education(Bank bank[],int banknum)
{
	string family[100];
	int familynum[100] = {0};
	int i = 0;
	int j = 0;
	int flag = 0;
	int max = 0;
			
	cout <<"**********education**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		for(j = 0; j < 100; j++)
		{
			if(bank[i].education == family[j])
			{
				familynum[j]++;
				break; 
			} 
			else if((bank[i].education != family[j])&&(j >= flag))
			{
				family[j] = bank[i].education;
				flag++;
				familynum[j]++;
				break;
			}
			else continue;
	    }
	}
	
	for(i = 0; i < flag; i++)
	{
		cout<<family[i] << " is " << familynum[i] <<". Frequency is " << (float)familynum[i]/banknum << endl;
	}
	for(i = 0; i < flag; i++)
	{
		max = familynum[i] > max ? familynum[i] : max;
	}
	
	for(i = 0; i <flag; i++)
	{
		if(max == familynum[i]) 
		{
			max = i;
			break;
		}
	}
	cout << "The most is " << family[i]<<endl;
	cout <<"\n\n\n";
}

void op_housing(Bank bank[],int banknum)
{
	string family[100];
	int familynum[100] = {0};
	int i = 0;
	int j = 0;
	int flag = 0;
	int max = 0;
			
	cout <<"**********housing**********"<<'\n';
	
	
	for(i = 0; i < banknum ; i++)
	{
		for(j = 0; j < 100; j++)
		{
			if(bank[i].housing == family[j])
			{
				familynum[j]++;
				break; 
			} 
			else if((bank[i].housing != family[j])&&(j >= flag))
			{
				family[j] = bank[i].housing;
				flag++;
				familynum[j]++;
				break;
			}
			else continue;
	    }
	}
	
	for(i = 0; i < flag; i++)
	{
		cout<<family[i] << " is " << familynum[i] <<". Frequency is " << (float)familynum[i]/banknum << endl;
	}
	for(i = 0; i < flag; i++)
	{
		max = familynum[i] > max ? familynum[i] : max;
	}
	
	for(i = 0; i <flag; i++)
	{
		if(max == familynum[i]) 
		{
			max = i;
			break;
		}
	}
	cout << "The most is " << family[i]<<endl;
	cout <<"\n\n\n";
}

void op_loan(Bank bank[],int banknum)
{
	string family[100];
	int familynum[100] = {0};
	int i = 0;
	int j = 0;
	int flag = 0;
	int max = 0;
			
	cout <<"**********loan**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		for(j = 0; j < 100; j++)
		{
			if(bank[i].loan == family[j])
			{
				familynum[j]++;
				break; 
			} 
			else if((bank[i].loan != family[j])&&(j >= flag))
			{
				family[j] = bank[i].loan;
				flag++;
				familynum[j]++;
				break;
			}
			else continue;
	    }
	}
	
	for(i = 0; i < flag; i++)
	{
		cout<<family[i] << " is " << familynum[i] <<". Frequency is " << (float)familynum[i]/banknum << endl;
	}
	for(i = 0; i < flag; i++)
	{
		max = familynum[i] > max ? familynum[i] : max;
	}
	
	for(i = 0; i <flag; i++)
	{
		if(max == familynum[i]) 
		{
			max = i;
			break;
		}
	}
	cout << "The most is " << family[i]<<endl;
	cout <<"\n\n\n";
}

void op_contact(Bank bank[],int banknum)
{
	string family[100];
	int familynum[100] = {0};
	int i = 0;
	int j = 0;
	int flag = 0;
	int max = 0;
			
	cout <<"**********contact**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		for(j = 0; j < 100; j++)
		{
			if(bank[i].contact == family[j])
			{
				familynum[j]++;
				break; 
			} 
			else if((bank[i].contact != family[j])&&(j >= flag))
			{
				family[j] = bank[i].contact;
				flag++;
				familynum[j]++;
				break;
			}
			else continue;
	    }
	}
	
	for(i = 0; i < flag; i++)
	{
		cout<<family[i] << " is " << familynum[i] <<". Frequency is " << (float)familynum[i]/banknum << endl;
	}
	for(i = 0; i < flag; i++)
	{
		max = familynum[i] > max ? familynum[i] : max;
	}
	
	for(i = 0; i <flag; i++)
	{
		if(max == familynum[i]) 
		{
			max = i;
			break;
		}
	}
	cout << "The most is " << family[i]<<endl;
	cout <<"\n\n\n";
}

void op_month(Bank bank[],int banknum)
{
	string family[100];
	int familynum[100] = {0};
	int i = 0;
	int j = 0;
	int flag = 0;
	int max = 0;
			
	cout <<"**********month**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		for(j = 0; j < 100; j++)
		{
			if(bank[i].month == family[j])
			{
				familynum[j]++;
				break; 
			} 
			else if((bank[i].month != family[j])&&(j >= flag))
			{
				family[j] = bank[i].month;
				flag++;
				familynum[j]++;
				break;
			}
			else continue;
	    }
	}
	
	for(i = 0; i < flag; i++)
	{
		cout<<family[i] << " is " << familynum[i] <<". Frequency is " << (float)familynum[i]/banknum << endl;
	}
	for(i = 0; i < flag; i++)
	{
		max = familynum[i] > max ? familynum[i] : max;
	}
	
	for(i = 0; i <flag; i++)
	{
		if(max == familynum[i]) 
		{
			max = i;
			break;
		}
	}
	cout << "The most is " << family[i]<<endl;
	cout <<"\n\n\n";
}

void op_poutcome(Bank bank[],int banknum)
{
	string family[100];
	int familynum[100] = {0};
	int i = 0;
	int j = 0;
	int flag = 0;
	int max = 0;
			
	cout <<"**********poutcome**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		for(j = 0; j < 100; j++)
		{
			if(bank[i].poutcome == family[j])
			{
				familynum[j]++;
				break; 
			} 
			else if((bank[i].poutcome != family[j])&&(j >= flag))
			{
				family[j] = bank[i].poutcome;
				flag++;
				familynum[j]++;
				break;
			}
			else continue;
	    }
	}
	
	for(i = 0; i < flag; i++)
	{
		cout<<family[i] << " is " << familynum[i] <<". Frequency is " << (float)familynum[i]/banknum << endl;
	}
	for(i = 0; i < flag; i++)
	{
		max = familynum[i] > max ? familynum[i] : max;
	}
	
	for(i = 0; i <flag; i++)
	{
		if(max == familynum[i]) 
		{
			max = i;
			break;
		}
	}
	cout << "The most is " << family[i]<<endl;
	cout <<"\n\n\n";
}

void op_y(Bank bank[],int banknum)
{
	string family[100];
	int familynum[100] = {0};
	int i = 0;
	int j = 0;
	int flag = 0;
	int max = 0;
			
	cout <<"**********y**********"<<'\n';
	
	for(i = 0; i < banknum ; i++)
	{
		for(j = 0; j < 100; j++)
		{
			if(bank[i].y == family[j])
			{
				familynum[j]++;
				break; 
			} 
			else if((bank[i].y != family[j])&&(j >= flag))
			{
				family[j] = bank[i].y;
				flag++;
				familynum[j]++;
				break;
			}
			else continue;
	    }
	}
	
	for(i = 0; i < flag; i++)
	{
		cout<<family[i] << " is " << familynum[i] <<". Frequency is " << (float)familynum[i]/banknum << endl;
	}
	for(i = 0; i < flag; i++)
	{
		max = familynum[i] > max ? familynum[i] : max;
	}
	
	for(i = 0; i <flag; i++)
	{
		if(max == familynum[i]) 
		{
			max = i;
			break;
		}
	}
	cout << "The most is " << family[i]<<endl;
	cout <<"\n\n\n";
}

/*	
void task(Bank bank[],int banknum)
{
	int sum[64] = {0};
	int flag[64] = {0};
	int i,j;
	for(i = 0; i < banknum; i++)
	{
		for(j = 0; j < 64; j++)
		{
		if(bank[i].campaigh == j) 
		{
			sum[j] =sum[j] + bank[i].duration;
			flag[j]++;
		}
		}
	}
	for(j = 0; j < 64; j++)
	{
		cout << j<<'\t'<<(float)sum[j]/flag[j] <<endl;
	}
}*/
 
